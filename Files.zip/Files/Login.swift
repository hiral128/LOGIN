//
//  Login.swift
//  Noli
//
//  Created by hiral kalola on 16/10/19.
//  Copyright © 2019 Impero Mac 1 . All rights reserved.
//

import UIKit

class Login: NSObject {
    UserDefault.shared.isAuthToken =  self.shareManager.GetCurrentUser.result.accessToken.accessToken
    UserDefault.shared.isLogin = true
    let jsonString = Mapper().toJSONString(self.shareManager.GetCurrentUser)
    UserDefault.shared.UserInfo = jsonString!
}
func Navigation(){
    if UserDefault.shared.isLogin{
        if UserDefault.shared.UserInfo != nil{
            ShareManager.GetCurrentUser = Mapper<SignupModel>().map(JSONString: UserDefault.shared.UserInfo)!
            if ShareManager.GetCurrentUser.result.userModel.profileStep == ProfileStep.MainTabbar{
            }else{
                AppDelegate.sharedInstance().moveLocationVc()
            }
        }else{
            SetDefaultLanguage()
            AppDelegate.sharedInstance().moveLocationVc()
            // moveLoginVC()
        }
    }
    func SignOut(){
         UserDefault.shared.removeUserDefault()
    }
    mutating func BetWeenTime(From:Date, End:Date) -> String{
        let calendar = Calendar.current
        let components: DateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: From, to: End)
        var Comp  = ""
        if components.second! < 60 {
            Comp = "Just Now"
        }
        if components.minute! >= 1{
            
            Comp = "\(components.minute!) minute ago"
        }
        if components.hour! >= 1{
            
            Comp = "\(components.hour!) Hours ago"
        }
        if components.day! >= 1{
            Comp = "\(components.day!) Day ago"
        }
        if components.month! >= 1{
            Comp = "\(components.month!) Month ago"
        }
        if components.year! >= 1 {
            Comp = "\(components.year!) Year ago"
        }
        return Comp
    }
    
    func StringToDate(CurrentDate:String)->Date{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = NSTimeZone.local
        let localdate  = dateFormatter.date(from: CurrentDate)
        return localdate!
    }
    extension AppDelegate : UNUserNotificationCenterDelegate{
        
        func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
            
        }
        
        func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
            
            let userinfo = userInfo
            let user = JSON(userinfo)
            let aps = user["aps"]
            let alert = aps["alert"]
            
            let notificationtype = user["notificationtype"].intValue
            print(user)
            if UIApplication.shared.applicationState == .inactive{
                if notificationtype == NotificationRedirection.Admin{
                    moveMainTabbar()
                }else if notificationtype == NotificationRedirection.PhotoAccess{
                    let UserId = user["UserId"].stringValue
                    moveUserProfileVc(UserID: UserId)
                    
                }else if notificationtype == NotificationRedirection.InappropriateImage{
                    GetUserDetailApi()
                    
                }else if notificationtype == NotificationRedirection.SendMessage{
                    ChatSignalR.shared.persistSignalr { (conStatus, getReciveMsg) in
                        
                    }
                    let UserId = user["UserId"].stringValue
                    self.moveUserChat(UserID: UserId)
                }
            }
            
            if UIApplication.shared.applicationState == .active{
                
                let notificationBar = GLNotificationBar(title: alert["title"].stringValue, message: alert["body"].stringValue, preferredStyle: .detailedBanner, handler: { (true) in
                    
                    if notificationtype == NotificationRedirection.Admin{
                        self.moveMainTabbar()
                    }else if notificationtype == NotificationRedirection.PhotoAccess{
                        let UserId = user["UserId"].stringValue
                        self.moveUserProfileVc(UserID: UserId)
                    }else if notificationtype == NotificationRedirection.InappropriateImage{
                        self.GetUserDetailApi()
                    }else if notificationtype == NotificationRedirection.SendMessage{
                        ChatSignalR.shared.delegateReceiveMessage?.GetHistoryMethod(response: true)
                        let UserId = user["UserId"].stringValue
                        if !self.isUserChatOpen{
                            if self.receiverUserID != UserId{
                                self.moveUserChat(UserID: UserId)
                            }
                        }else{
                            self.moveUserChat(UserID: UserId)
                        }
                    }
                    
                })
                notificationBar.showTime(3)
            }
        }
        
        
    }
    
    
    
    
    
    import UIKit
    import UserNotifications
    import FirebaseInstanceID
    import FirebaseMessaging
    import Firebase
    import SwiftyJSON
    class FCMNotification: NSObject,UNUserNotificationCenterDelegate,MessagingDelegate {
        
        static let shared = FCMNotification()
        
        typealias CompletionHandler = (_ isdeivce:String) -> ()
        
        var handler : CompletionHandler?
        
        func registerNotification(completionHandler:@escaping CompletionHandler){
            handler = completionHandler
            if #available(iOS 10.0, *) {
                // For iOS 10 display notification (sent via APNS)
                UNUserNotificationCenter.current().delegate = self
                let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
                UNUserNotificationCenter.current().requestAuthorization(
                    options: authOptions,
                    completionHandler: {_, _ in })
                // For iOS 10 data message (sent via FCM
                Messaging.messaging().delegate = self
            } else {
                let settings: UIUserNotificationSettings =
                    UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
                UIApplication.shared.registerUserNotificationSettings(settings)
            }
            UIApplication.shared.registerForRemoteNotifications()
            FirebaseApp.configure()
        }
        
        func messaging(_ messaging: Messaging, didRefreshRegistrationToken fcmToken: String) {
            print(fcmToken)
            handler!(fcmToken)
            UserDefaults.standard.set(fcmToken, forKey: "token")
        }
        func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
            let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
            print(deviceTokenString)
            
        }
        func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
            handler!("1234")
        }
        
        
}
